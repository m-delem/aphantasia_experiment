jspsych-poldrack-multi-stim-multi-response

Modified version of the original jspsych-multi-stim-multi-response. Almost identical except for an additional timing gap
